<?php
exit('new data');
?>