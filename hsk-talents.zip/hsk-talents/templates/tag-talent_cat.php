<?php
	exit('test');
?>